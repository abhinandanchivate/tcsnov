package com.tcs.sampleproj;

import java.io.File;
import java.io.IOException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tcs.sampleproj.model.Staff;

public class Main2 {

	public static void main(String[] args) {
		
		ObjectMapper mapper = new ObjectMapper();
		
		
		
		Staff[] staff = null;
		
		try {
			staff = mapper.readValue(new File("sample.json"), Staff[].class);
			
			for (Staff staff2 : staff) {
				System.out.println(staff2);
			}
			System.out.println(staff);
			
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
