package com.tcs.sampleproj;

import java.lang.annotation.Annotation;
import java.lang.reflect.Constructor;

public class AnnotationMain {

	public static void main(String[] args) {
	
		try {
			System.out.println("inside the main");
			Class class1  = Class.forName("com.tcs.sampleproj.model.Staff");
			
			Annotation[] annotations = class1.getAnnotations();
			
			for (Annotation annotation : annotations) {
				System.out.println(annotation);
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
