package com.tcs.sampleproj.model;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;


@JsonIgnoreProperties({"salary","position"})
public class Staff {
	public Staff() {
		// TODO Auto-generated constructor stub
	}
	public Staff(String name, int age, String[] position, List<String> skills, Map<String, BigDecimal> salary) {
		super();
		this.name = name;
		this.age = age;
		this.position = position;
		this.skills = skills;
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Staff [name=" + name + ", age=" + age + ", position=" + Arrays.toString(position) + ", skills=" + skills
				+ ", salary=" + salary + "]";
	}
	@JsonProperty("custmer_name")
	private String name;
	private String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String[] getPosition() {
		return position;
	}
	public void setPosition(String[] position) {
		this.position = position;
	}
	public List<String> getSkills() {
		return skills;
	}
	public void setSkills(List<String> skills) {
		this.skills = skills;
	}
	public Map<String, BigDecimal> getSalary() {
		return salary;
	}
	public void setSalary(Map<String, BigDecimal> salary) {
		this.salary = salary;
	}
	
	@JsonProperty("age_value")
	private int age;
	//@JsonIgnore
	private String[] position;
	private List<String> skills;
	//@JsonIgnore
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Map<String, BigDecimal> salary;

}
