package com.tcs.sampleproj;

import java.lang.annotation.Annotation;
import java.lang.reflect.Constructor;

public class ReflectionMain {
	
	public static void main(String[] args) {
		
		try {
			System.out.println("inside the main");
			Class class1  = Class.forName("com.tcs.sampleproj.model.Staff");
			
			Constructor constructor[] = class1.getConstructors();
			
			for (Constructor constructor2 : constructor) {
				System.out.println(constructor2);
			}
//		Annotation[] annotation = class1.getAnnotations();
//		System.out.println(annotation.length);
//		for (Annotation annotation2 : annotation) {
//			
//			System.out.println(annotation2);
//		}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
