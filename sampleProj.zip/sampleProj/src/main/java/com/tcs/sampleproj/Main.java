package com.tcs.sampleproj;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tcs.sampleproj.model.Staff;

public class Main {
// here we have a file called sample.json
	 
	// 2. read a json file.
	
	
	public static void main(String[] args) {
		
	
		// 1 write a json file
		
		// use this class to read/write java objects in a json file.
		
		ObjectMapper mapper = new ObjectMapper();
		Staff staff = createStaff();
		
		try {
			mapper.writeValue(new File("sample.json"), staff);
			String jsonDetails = mapper.writeValueAsString(staff);
			
			System.out.println(jsonDetails);
			
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	private static Staff createStaff() {
		
		Staff staff = new Staff();
		
		staff.setName("abhi");
		staff.setAge(31);
		staff.setPosition(new String[] {"trainer","founder","author"});
		
		Map<String, BigDecimal> salary = new HashMap<String, BigDecimal>(){{
			put("2020",new BigDecimal(1000));
			put("2019",new BigDecimal(5000));
			put("2018",new BigDecimal(100));
		}};
		
		//staff.setSalary(salary);
		staff.setSkills(Arrays.asList("java","spring"));
		return staff;
		
	}
}
