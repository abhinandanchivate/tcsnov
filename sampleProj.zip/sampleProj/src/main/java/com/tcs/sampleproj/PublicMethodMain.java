package com.tcs.sampleproj;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import com.tcs.sampleproj.model.Staff;

public class PublicMethodMain {
	
	public static void main(String[] args) {
		
		System.out.println("inside the main");
		try {
			Class class1  = Class.forName("com.tcs.sampleproj.model.Staff");
		
			Method[] methods= class1.getDeclaredMethods();
			
			
			Method[] method = class1.getMethods();
			for (Method method2 : methods) {
				System.out.println(method2 +"   "+Modifier.toString(method2.getModifiers()));
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
